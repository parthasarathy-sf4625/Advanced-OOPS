﻿using System;
namespace OnlineGroceryApp
{
    public class Program 
    {
        public static void Main(string[] args)
        {
            Operations.AddDefaultDetails();
            Operations.MainMenu();
            
        }
    }
}